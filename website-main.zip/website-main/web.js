function diplayContactApp() {
  document.getElementById("content").innerHTML =
    '<iframe src="//www.codiva.io/em/p/6d2cc43d-3dc9-40d9-bd1f-5756cf9f9db5" style="height: 600px; min-height: 420px; max-height: 90vh; width: 100%; overflow: hidden;"></iframe>';
}
function diplayLinkedList() {
    document.getElementById("content").innerHTML =
      '<iframe src="https://www.codiva.io/em/p/124fc064-692a-4723-8e9b-9b871ed5d5c4" style="height: 600px; min-height: 420px; max-height: 90vh; width: 100%; overflow: hidden;"></iframe>';
   
  }
  function diplayCasino() {
    document.getElementById("content").innerHTML =
      '<iframe src="https://www.codiva.io/em/p/32f7e708-fcfd-494d-a8b8-20493afe6a68" style="height: 600px; min-height: 420px; max-height: 90vh; width: 100%; overflow: hidden;"></iframe>';
   
  } 
  